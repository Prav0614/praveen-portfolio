from django.urls import path 
from .import views 
urlpatterns=[ 
    path('',views.index,name='homepage'),
    path('contacts',views.contacts,name='contacts'),
    path('aircrafts',views.aircrafts,name='aircrafts'),
    path('register',views.register,name='reg'),
    path('login',views.login,name='login'),
    path('otp',views.otpVerify, name='otpVerify'),
    path('logout',views.logout,name='logout')
]