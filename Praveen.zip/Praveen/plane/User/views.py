from django.shortcuts import render,redirect
from django.contrib.auth.models import User,auth
from django.contrib import messages
import math
import random
from django.http import HttpResponseRedirect
otp=None
# Create your views here.
def index(request):
    return render(request,"index.html")

def contacts(request):
    return render(request,"contacts.html")

def aircrafts(request):
    return render(request,"aircrafts.html")

def register(request):
    if request.method=="POST":
        first=request.POST['fname']
        last=request.POST['lname']
        uname=request.POST['uname']
        em=request.POST['email']
        p1=request.POST['psw']
        p2=request.POST['psw1']
        if p1==p2:
            if User.objects.filter(username=uname).exists():
                messages.info(request,"Username Exists")
                return render(request,"register.html")
            elif User.objects.filter(email=em).exists():
                messages.info(request,"Email Exists")
                return render(request,"register.html")
            else:
                user=User.objects.create_user(first_name=first,last_name=last,
                username=uname,email=em,password=p1)
                user.save()
                return redirect('login')
        else:
            messages.info(request,"Password not matching")
            return render(request,"register.html")
    return render(request,"register.html")

def login(request):
    if request.method=="POST":
        u=request.POST['uname']
        p=request.POST['psw']
        user=auth.authenticate(username=u,password=p)
        if user is not None:
            auth.login(request,user)
            return redirect('otpVerify')
        else:
            messages.info(request,"Invalid Credentials")
            return render(request,"login.html")
    return render(request,"login.html")

def logout(request):
    auth.logout(request)
    return redirect('/')

def otp(request):
      return render(request,"otp.html")

def otpGen(request):
	string = '0123456789'
	otp = ''
	for i in range(6):
		OTP += string[math.floor(random.random() * len(string))]
	return otp

def otpSend(request,user,otp):
	from redmail import outlook
	outlook.user_name = "projecthumanstress@outlook.com"
	outlook.password = "humanstress@1234"
	outlook.send(
        receivers=user.email,
        subject="otp",
            #text="Hi, this is an example."
        text = """\
                Hi,
               "OTP",
			"Your OTP is "{0}". Do not share it with anyone by any means. This is confidential and to be used by you only.",
			'admin@no-reply.com',
                


                    \
                """.format( otp))

""" emailto = user.email
    if emailto:
		
    	send_mail(
			"OTP",
			"Your OTP is "+otp+". Do not share it with anyone by any means. This is confidential and to be used by you only.",
			'admin@no-reply.com',
			[emailto],
			fail_silently=False,
			)"""

def otpVerify(request):
	global otp
	user = request.user
	if otp == None:
		otp = otpGen(request)
		otpSend(request,user,otp)
		return render(request,'otp.html')
	else:
		if request.method == "POST":
			otpfield = request.POST['otp']
			if otpfield == otp:
				return redirect('/')
			else:
                
				auth.logout(request)
                
				return HttpResponse('Otp Wrong')
		else:
			otp = otpGen(request)
			otpSend(request,user,otp)
			auth.logout(request)
			return render(request,'otp.html')